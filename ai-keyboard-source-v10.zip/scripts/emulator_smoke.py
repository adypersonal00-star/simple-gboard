import subprocess,re,time,sys
PKG='com.zapia.simplegboard'; SERVICE=PKG+'/.SimpleKeyboardService'
def run(*a,check=True): return subprocess.run(a,check=check,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout
def dump():
 run('adb','shell','uiautomator','dump','/sdcard/ui.xml',check=False)
 return run('adb','shell','cat','/sdcard/ui.xml',check=False)
def tap_label(s,timeout=18):
 end=time.time()+timeout
 while time.time()<end:
  x=dump()
  for m in re.finditer(r'<node[^>]+text="([^"]*)"[^>]+bounds="(\[[^\"]+\])"',x):
   text,b=m.groups()
   if s.casefold() in text.casefold():
    q=re.match(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]',b)
    if q:
     a,b,c,d=map(int,q.groups());run('adb','shell','input','tap',str((a+c)//2),str((b+d)//2));time.sleep(.8);return
  run('adb','shell','input','swipe','700','2500','700','900','300');time.sleep(.4)
 raise AssertionError('No se localiza '+s+'\n'+x)
run('adb','shell','pm','clear',PKG,check=False)
run('adb','install','-r','app/build/outputs/apk/debug/app-debug.apk')
run('adb','shell','ime','enable',SERVICE)
run('adb','shell','ime','set',SERVICE)
run('adb','shell','am','start','-n',PKG+'/.SetupActivity');time.sleep(3)
assert 'AI Keyboard' in dump()
tap_label('Prueba el teclado aquí')
time.sleep(1)
u=dump()
for key in ['q','w','1','⌫','🎙']:
 assert key in u, 'No visible IME key: '+key
# tap the lower-row q key by locating exact accessible text
m=re.search(r'<node[^>]+text="q"[^>]+bounds="(\[[^\"]+\])"',u)
if m:
 a,b,c,d=map(int,re.findall(r'\d+',m.group(1)));run('adb','shell','input','tap',str((a+c)//2),str((b+d)//2));time.sleep(.5)
assert 'q' in dump().lower(), 'La tecla no escribió en el campo de prueba'
# exercise emoji and symbol mode controls via accessible labels
assert '😊' in dump() and '?123' in dump()
logs=run('adb','logcat','-d','-t','500',check=False)
assert 'FATAL EXCEPTION' not in logs,logs[-5000:]
print('IME_SMOKE_OK: launch setup, activate/select IME, visible letter/number/delete/voice keys, type into editor, emoji and symbol controls present')
