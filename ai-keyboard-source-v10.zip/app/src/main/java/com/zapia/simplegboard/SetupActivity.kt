package com.zapia.simplegboard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SetupActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  setContent {
   val prefs=getSharedPreferences("ai_keyboard",MODE_PRIVATE)
   var testText by remember { mutableStateOf("") }
   var keyRound by remember { mutableStateOf(prefs.getBoolean("round",true)) }
   var blockLetters by remember { mutableStateOf(prefs.getBoolean("square_font",false)) }
   var keyHeight by remember { mutableFloatStateOf(prefs.getInt("height",66).toFloat()) }
   var keyboardBg by remember { mutableIntStateOf(prefs.getInt("bg",0xFF0D121C.toInt())) }
   var keysBg by remember { mutableIntStateOf(prefs.getInt("key",0xFF1E293B.toInt())) }
   var lettersColor by remember { mutableIntStateOf(prefs.getInt("fg",Color.White.toArgb())) }
   var outlineColor by remember { mutableIntStateOf(prefs.getInt("border",0xFF5F738C.toInt())) }
   val voicePermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
   val gifPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
    if(uri!=null){runCatching{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)};prefs.edit().putString("pending_gif_uri",uri.toString()).apply();finish()}
   }
   LaunchedEffect(intent.getBooleanExtra("pick_gif",false),intent.getBooleanExtra("request_voice",false)) {
    if(intent.getBooleanExtra("pick_gif",false)) gifPicker.launch(arrayOf("image/gif"))
    if(intent.getBooleanExtra("request_voice",false)&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) voicePermission.launch(Manifest.permission.RECORD_AUDIO)
   }
   fun persist(){prefs.edit().putInt("bg",keyboardBg).putInt("key",keysBg).putInt("fg",lettersColor).putInt("border",outlineColor).putBoolean("round",keyRound).putBoolean("square_font",blockLetters).putInt("height",keyHeight.toInt()).apply()}
   MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF8ED7FF),background=Color(0xFF0D121C),surface=Color(0xFF1E293B),onSurface=Color.White)) {
    Column(Modifier.fillMaxSize().background(Color(0xFF0D121C)).verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
     Text("AI Keyboard",fontSize=28.sp,fontWeight=FontWeight.Black,color=Color.White)
     Text("Teclado Android nativo. El texto permanece en el teléfono.",color=Color(0xFFBAD0E6))
     Button(onClick={startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))},modifier=Modifier.fillMaxWidth()){Text("Activar teclado")}
     OutlinedButton(onClick={(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()},modifier=Modifier.fillMaxWidth()){Text("Elegir AI Keyboard")}
     OutlinedTextField(value=testText,onValueChange={testText=it},label={Text("Prueba el teclado aquí")},modifier=Modifier.fillMaxWidth())
     OutlinedButton(onClick={if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)voicePermission.launch(Manifest.permission.RECORD_AUDIO)},modifier=Modifier.fillMaxWidth()){Text(if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)"Dictado activado" else "Permitir dictado")}
     HorizontalDivider();Text("Apariencia",fontWeight=FontWeight.Bold)
     Row(verticalAlignment=Alignment.CenterVertically){Text("Teclas redondeadas",Modifier.weight(1f));Switch(keyRound,{keyRound=it;persist()})}
     Row(verticalAlignment=Alignment.CenterVertically){Text("Letras cuadradas Unicode",Modifier.weight(1f));Switch(blockLetters,{blockLetters=it;persist()})}
     Text("Altura: ${keyHeight.toInt()} dp");Slider(keyHeight,{keyHeight=it;persist()},valueRange=56f..80f)
     ColorChoice("Fondo del teclado",keyboardBg,listOf(0xFF0D121C.toInt(),0xFF000000.toInt(),0xFF263238.toInt(),0xFF263A50.toInt())){keyboardBg=it;persist()}
     ColorChoice("Fondo de las teclas",keysBg,listOf(0xFF1E293B.toInt(),0xFF333333.toInt(),0xFF243B53.toInt(),0xFF444444.toInt())){keysBg=it;persist()}
     ColorChoice("Color de letra",lettersColor,listOf(Color.White.toArgb(),0xFF8ED7FF.toInt(),0xFFFFE082.toInt(),0xFFB8F28B.toInt())){lettersColor=it;persist()}
     ColorChoice("Contorno de las teclas",outlineColor,listOf(0xFF5F738C.toInt(),Color.White.toArgb(),0xFF8ED7FF.toInt(),0xFF000000.toInt())){outlineColor=it;persist()}
     HorizontalDivider()
     Text("La versión actual ofrece sugerencias locales básicas; todavía no integra Qwen ni corrección inteligente con IA. El dibujo a bloques es una conversión geométrica local, no una función de IA.",fontSize=13.sp,color=Color(0xFFBAD0E6))
    }
   }
  }
 }
}
@Composable private fun ColorChoice(title:String,selected:Int,colors:List<Int>,onSelect:(Int)->Unit){
 Column {
  Text(title,fontSize=13.sp,color=Color(0xFFBAD0E6))
  Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
   colors.forEach { color -> Box(Modifier.size(34.dp).background(Color(color),RoundedCornerShape(8.dp)).border(if(selected==color)3.dp else 1.dp,Color.White,RoundedCornerShape(8.dp)).clickable{onSelect(color)}) }
  }
 }
}
