package com.zapia.simplegboard

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputContentInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.view.inputmethod.SurroundingText
import java.util.Locale
import kotlin.math.max

/** A real Android IME. Text stays in the active editor; no keystrokes are sent to a server. */
class SimpleKeyboardService : InputMethodService() {
    private var caps=false
    private var panel="letters"
    private var speech:SpeechRecognizer?=null
    private var suggestions=listOf<String>()
    private val prefs by lazy { getSharedPreferences("ai_keyboard", MODE_PRIVATE) }
    private val emojis=listOf("😀","😃","😄","😁","😂","🙂","😉","😊","😍","🥰","😘","😎","🤩","🥳","😭","😢","😡","👍","👎","👏","🙏","❤️","💙","💚","💛","💜","✨","🔥","🎉","🌈","⭐","✅")

    override fun onCreateInputView():View=buildKeyboard()
    override fun onStartInput(attribute:EditorInfo?,restarting:Boolean){super.onStartInput(attribute,restarting);caps=false;panel="letters";suggestions=emptyList()}
    override fun onStartInputView(info:EditorInfo?,restarting:Boolean){
        super.onStartInputView(info,restarting)
        val pending=prefs.getString("pending_gif_uri",null)
        if(!pending.isNullOrBlank()){
            runCatching {
                val uri=Uri.parse(pending);val desc=ClipDescription("GIF",arrayOf("image/gif"));val content=InputContentInfo(uri,desc,null)
                if(Build.VERSION.SDK_INT>=25){val ok=currentInputConnection?.commitContent(content,android.view.inputmethod.InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION,Bundle())?:false;if(!ok)Toast.makeText(this,"Esta aplicación no admite insertar GIFs desde el teclado",Toast.LENGTH_LONG).show()}
                else Toast.makeText(this,"El campo no admite GIFs",Toast.LENGTH_SHORT).show()
            }
            prefs.edit().remove("pending_gif_uri").apply()
        }
    }
    private fun dp(x:Int)=(x*resources.displayMetrics.density+.5f).toInt()
    private fun color(key:String, fallback:Int)=prefs.getInt(key,fallback)
    private fun bgColor()=color("bg",Color.rgb(13,18,28))
    private fun keyColor()=color("key",Color.rgb(30,41,59))
    private fun fgColor()=color("fg",Color.WHITE)
    private fun borderColor()=color("border",Color.rgb(95,115,140))
    private fun round()=prefs.getBoolean("round",true)
    private fun height()=prefs.getInt("height",66)
    private fun squareFont()=prefs.getBoolean("square_font",false)

    private fun buildKeyboard():View {
        if(panel=="hand"||panel=="art")return buildCanvas(panel=="hand")
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bgColor());setPadding(dp(4),dp(4),dp(4),dp(4));contentDescription="AI Keyboard"}
        addToolbar(root)
        if(panel=="clipboard"){addClipboard(root);return root}
        if(panel=="special"){addSpecial(root);return root}
        if(panel=="gif"){addGif(root);return root}
        if(panel=="emoji"){addGrid(root,emojis,8);bottom(root);return root}
        if(panel=="symbols"){
            addRow(root,"1234567890".map{it.toString()},height=height()-8)
            listOf("!@#$%&*()-","_+=/\\:;?\"'",".,[]{}~<>€£¥¢","§¶©®™°±×÷√∞•").forEach{addRow(root,it.map(Char::toString),height=height()-8)}
            bottom(root);return root
        }
        if(suggestions.isNotEmpty()){val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER};suggestions.take(3).forEach{w->row.addView(key(w){replaceLastWord(w)},LinearLayout.LayoutParams(0,dp(34),1f).apply{setMargins(dp(2),0,dp(2),0)})};root.addView(row)}
        addRow(root,"1234567890".map{it.toString()},height=height()-8)
        addLetters(root,"qwertyuiop");addLetters(root,"asdfghjkl");addLetters(root,"zxcvbnm")
        bottom(root)
        return root
    }
    private fun addToolbar(root:LinearLayout){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val tools=listOf("🎙" to "voice","📋" to "clipboard","GIF" to "gif","✦" to "special","✍" to "hand","▦" to "art","⚙" to "settings")
        tools.forEach{(label,act)->
            val action:()->Unit={
                when(act){
                    "voice"->voice()
                    "clipboard"->{panel="clipboard";refresh()}
                    "gif"->startActivity(android.content.Intent(this,SetupActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("pick_gif",true))
                    "special"->{panel="special";refresh()}
                    "hand"->{panel="hand";refresh()}
                    "art"->{panel="art";refresh()}
                    else->startActivity(android.content.Intent(this,SetupActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            val accessible=when(act){"voice"->"Dictado por voz";"clipboard"->"Portapapeles";"gif"->"GIF";"special"->"Caracteres especiales";"hand"->"Dibujo de letra";"art"->"Dibujo a bloques";else->"Ajustes del teclado"}
            row.addView(key(label,action).apply{contentDescription=accessible},LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(1),0,dp(1),0)})
        }
        root.addView(row)
    }
    private fun addLetters(root:LinearLayout, row:String){
        val line=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        row.forEach{c->val v=if(caps)c.uppercaseChar() else c;line.addView(key(if(squareFont())blockGlyph(v) else v.toString()){insert(if(squareFont())blockGlyph(v) else v.toString());checkWord()},LinearLayout.LayoutParams(0,dp(height()),1f).apply{setMargins(dp(2),dp(2),dp(2),dp(2))})}
        root.addView(line,LinearLayout.LayoutParams(-1,dp(height()+4)))
    }
    private fun addRow(root:LinearLayout,labels:List<String>,height:Int=48){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER};labels.forEach{v->r.addView(key(v){insert(v);checkWord()},LinearLayout.LayoutParams(0,dp(height),1f).apply{setMargins(dp(1),dp(1),dp(1),dp(1))})};root.addView(r,LinearLayout.LayoutParams(-1,dp(height+2)))}
    private fun bottom(root:LinearLayout){
        val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        val items=listOf("↵" to {enter()},"⌫" to {delete()},"Español (EC)" to {insert(" ")},"😊" to {panel="emoji";refresh()},"?123" to {panel="symbols";refresh()})
        val ws=listOf(1.05f,1.05f,3.35f,1.1f,1.2f)
        items.forEachIndexed{i,p->val b=key(p.first,p.second);b.contentDescription=when(i){0->"Intro";1->"Eliminar";2->"Espacio";3->"Emoji";else->"Símbolos"};r.addView(b,LinearLayout.LayoutParams(0,dp(height()+3),ws[i]).apply{setMargins(dp(2),dp(2),dp(2),dp(2))})}
        root.addView(r)
    }
    private fun key(label:String,action:()->Unit):Button=Button(this).apply{
        text=label;contentDescription=when(label){"⌫"->"Eliminar carácter";"↵"->"Intro";"English (US)","Español (EC)"->"Espacio";else->label}
        setTextColor(fgColor());textSize=when{label.length>7->11f;label.length>3->13f;else->20f};typeface=if(squareFont()&&label.length==1)Typeface.MONOSPACE else Typeface.DEFAULT_BOLD
        isAllCaps=false;minWidth=0;minimumWidth=0;minHeight=0;minimumHeight=0;setPadding(dp(2),0,dp(2),0)
        background=GradientDrawable().apply{shape=if(round())GradientDrawable.RECTANGLE else GradientDrawable.RECTANGLE;setColor(keyColor());setStroke(dp(1),borderColor());cornerRadius=if(round())dp(15).toFloat() else dp(3).toFloat()}
        setOnClickListener{action()}
    }
    private fun addGrid(root:LinearLayout,items:List<String>,cols:Int){val sc=ScrollView(this);val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};items.chunked(cols).forEach{values->val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};values.forEach{v->r.addView(key(v){insert(v)},LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(dp(1),dp(1),dp(1),dp(1))})};grid.addView(r)};sc.addView(grid);root.addView(sc,LinearLayout.LayoutParams(-1,dp(220)))}
    private fun addClipboard(root:LinearLayout){
        val clip=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clipboardText=if(clip.hasPrimaryClip())clip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty() else ""
        root.addView(TextView(this).apply{text="Portapapeles · último elemento";setTextColor(fgColor());textSize=14f;gravity=Gravity.CENTER;setPadding(dp(8),dp(8),dp(8),dp(8))})
        if(clipboardText.isNotBlank()) root.addView(key(clipboardText.take(72)){insert(clipboardText)} ,LinearLayout.LayoutParams(-1,dp(56))) else root.addView(TextView(this).apply{text="El portapapeles está vacío";setTextColor(fgColor());gravity=Gravity.CENTER})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};actions.addView(key("Pegar"){if(clipboardText.isNotBlank())insert(clipboardText);panel="letters";refresh()},LinearLayout.LayoutParams(0,dp(42),1f));actions.addView(key("Cerrar"){panel="letters";refresh()},LinearLayout.LayoutParams(0,dp(42),1f));root.addView(actions)
    }
    private fun addSpecial(root:LinearLayout){
        val symbols=(0x00A1..0x00FF).map{String(Character.toChars(it))}+listOf("→","←","↑","↓","✓","✗","★","☆","♠","♣","♥","♦","∞","∑","π","√","≈","≠","≤","≥","₀","₁","₂","₃","⁰","¹","²","³","·","…","—","–","“","”","‘","’","©","®","™","℃","°")
        root.addView(TextView(this).apply{text="Caracteres y símbolos Unicode";setTextColor(fgColor());gravity=Gravity.CENTER;textSize=15f})
        val sc=ScrollView(this);val g=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};symbols.chunked(8).forEach{row->val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};row.forEach{ch->r.addView(key(ch){insert(ch)},LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(dp(1),dp(1),dp(1),dp(1))})};g.addView(r)};sc.addView(g);root.addView(sc,LinearLayout.LayoutParams(-1,dp(235)));root.addView(key("Cerrar"){panel="letters";refresh()},LinearLayout.LayoutParams(-1,dp(40)))
    }
    private fun addGif(root:LinearLayout){
        root.addView(TextView(this).apply{text="GIF · elige uno del dispositivo";setTextColor(fgColor());gravity=Gravity.CENTER;textSize=15f})
        root.addView(key("📂 Elegir GIF"){startActivity(android.content.Intent(this,SetupActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("pick_gif",true))},LinearLayout.LayoutParams(-1,dp(72)))
        root.addView(TextView(this).apply{text="En editores compatibles lo adjunta como imagen; en campos de texto que no admiten GIF, no se enviará.";setTextColor(fgColor());textSize=13f;gravity=Gravity.CENTER;setPadding(dp(8),dp(8),dp(8),dp(8))})
        root.addView(key("Cerrar"){panel="letters";refresh()},LinearLayout.LayoutParams(-1,dp(40)))
    }
    private fun buildCanvas(hand:Boolean):View{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bgColor());setPadding(dp(6),dp(5),dp(6),dp(5))}
        val title=TextView(this).apply{text=if(hand)"Dibuja una letra" else "Dibuja → bloques Unicode";setTextColor(fgColor());gravity=Gravity.CENTER;textSize=16f};root.addView(title,LinearLayout.LayoutParams(-1,dp(34)))
        val canvas=InkView(this);root.addView(canvas,LinearLayout.LayoutParams(-1,0,1f))
        val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        r.addView(key("Borrar"){canvas.clear()},LinearLayout.LayoutParams(0,dp(44),1f))
        r.addView(key(if(hand)"Reconocer" else "Convertir a bloques"){val points=canvas.points();if(hand){val ch=recognize(points);if(ch!=null)insert(ch.toString()) else Toast.makeText(this@SimpleKeyboardService,"No reconocí la letra; prueba otra vez",Toast.LENGTH_SHORT).show()}else insert(toBlocks(points));panel="letters";refresh()},LinearLayout.LayoutParams(0,dp(44),2f))
        r.addView(key("Cerrar"){panel="letters";refresh()},LinearLayout.LayoutParams(0,dp(44),1f));root.addView(r)
        return root
    }
    private class InkView(ctx:android.content.Context):View(ctx){private val path=Path();private val all=mutableListOf<PointF>();private var p:Paint=Paint(3).apply{color=Color.WHITE;strokeWidth=14f;style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND};private val paper=Paint(3).apply{color=Color.rgb(26,36,52)}
        fun points()=all.toList();fun clear(){path.reset();all.clear();invalidate()}
        override fun onDraw(c:Canvas){super.onDraw(c);c.drawRoundRect(0f,0f,width.toFloat(),height.toFloat(),20f,20f,paper);c.drawPath(path,p)}
        override fun onTouchEvent(e:MotionEvent):Boolean{val x=e.x;val y=e.y;when(e.action){MotionEvent.ACTION_DOWN->{path.moveTo(x,y);all.add(PointF(x,y));invalidate();return true};MotionEvent.ACTION_MOVE->{path.lineTo(x,y);all.add(PointF(x,y));invalidate();return true};MotionEvent.ACTION_UP->{path.lineTo(x,y);all.add(PointF(x,y));invalidate();return true}};return true}
    }
    private fun toBlocks(pts:List<PointF>):String{if(pts.size<2)return "";val minX=pts.minOf{it.x};val maxX=max(minX+1,pts.maxOf{it.x});val minY=pts.minOf{it.y};val maxY=max(minY+1,pts.maxOf{it.y});val cols=14;val rows=7;val grid=Array(rows){CharArray(cols){' '}};pts.forEach{p->val x=((p.x-minX)/(maxX-minX)*(cols-1)).toInt().coerceIn(0,cols-1);val y=((p.y-minY)/(maxY-minY)*(rows-1)).toInt().coerceIn(0,rows-1);grid[y][x]='█'};return grid.joinToString("\n"){String(it).trimEnd()}.trim()}
    private fun recognize(pts:List<PointF>):Char?{if(pts.size<3)return null;val minX=pts.minOf{it.x};val maxX=max(minX+1,pts.maxOf{it.x});val minY=pts.minOf{it.y};val maxY=max(minY+1,pts.maxOf{it.y});val w=5;val h=7;val ink=Array(h){BooleanArray(w)};pts.forEach{p->val x=(((p.x-minX)/(maxX-minX)*(w-1))).toInt().coerceIn(0,w-1);val y=(((p.y-minY)/(maxY-minY)*(h-1))).toInt().coerceIn(0,h-1);ink[y][x]=true};val templates=mapOf('I' to listOf("#####","..#..","..#..","..#..","..#..","..#..","#####"),'L' to listOf("#....","#....","#....","#....","#....","#....","#####"),'O' to listOf(".###.","#...#","#...#","#...#","#...#","#...#",".###."),'C' to listOf(".####","#....","#....","#....","#....","#....",".####"),'T' to listOf("#####","..#..","..#..","..#..","..#..","..#..","..#.."),'E' to listOf("#####","#....","#....","####.","#....","#....","#####"),'1' to listOf("..#..",".##..","..#..","..#..","..#..","..#..",".###."),'7' to listOf("#####","....#","...#.","..#..",".#...",".#...",".#..."));var best:Char?=null;var score=Int.MAX_VALUE;templates.forEach{(ch,rows)->var d=0;for(y in 0 until h)for(x in 0 until w)if(ink[y][x]!=(rows[y][x]=='#'))d++;if(d<score){score=d;best=ch}};return if(score<=18)best else null}
    private fun blockGlyph(c:Char):String { val u=c.uppercaseChar();return if(u in 'A'..'Z')String(Character.toChars(0x1F130+(u-'A'))) else if(u=='Ñ')"Ñ" else u.toString() }

    private fun insert(s:String){val ic=currentInputConnection?:return;ic.commitText(s,1)}
    private fun delete(){currentInputConnection?.deleteSurroundingText(1,0)}
    private fun replaceLastWord(s:String){val ic=currentInputConnection?:return;val before=ic.getTextBeforeCursor(80,0)?.toString().orEmpty();val len=before.takeLastWhile{!it.isWhitespace()}.length;if(len>0){ic.deleteSurroundingText(len,0);ic.commitText(s,1)};suggestions=emptyList();refresh()}
    private fun checkWord(){
        val before=currentInputConnection?.getTextBeforeCursor(80,0)?.toString().orEmpty()
        val word=before.takeLastWhile{it.isLetter()}
        val fixes=mapOf("qeu" to "que","qe" to "que","d ela" to "de la","ola" to "hola","aver" to "a ver","haci" to "así","tambien" to "también","mas" to "más","porque" to "porque")
        suggestions=fixes[word.lowercase(Locale.ROOT)]?.let{listOf(it)}?:emptyList()
        if(suggestions.isNotEmpty())handler.post{if(panel=="letters")refresh()}
    }
    private val handler=android.os.Handler(android.os.Looper.getMainLooper())
    private fun enter(){val ic=currentInputConnection?:return;val action=currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)?:EditorInfo.IME_ACTION_UNSPECIFIED;when(action){EditorInfo.IME_ACTION_GO,EditorInfo.IME_ACTION_SEARCH,EditorInfo.IME_ACTION_SEND,EditorInfo.IME_ACTION_NEXT,EditorInfo.IME_ACTION_DONE->ic.performEditorAction(action);else->ic.commitText("\n",1)}}
    private fun voice(){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){startActivity(android.content.Intent(this,SetupActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("request_voice",true));return}
        if(!SpeechRecognizer.isRecognitionAvailable(this))return
        runCatching {
            speech?.destroy()
            val recognizer=SpeechRecognizer.createSpeechRecognizer(this)
            speech=recognizer
            recognizer.setRecognitionListener(object:RecognitionListener{
                override fun onResults(b:Bundle?){b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let{insert(it+" ");checkWord()};recognizer.destroy();speech=null}
                override fun onError(e:Int){recognizer.destroy();speech=null}
                override fun onReadyForSpeech(p:Bundle?){}
                override fun onBeginningOfSpeech(){}
                override fun onRmsChanged(v:Float){}
                override fun onBufferReceived(b:ByteArray?){}
                override fun onEndOfSpeech(){}
                override fun onPartialResults(b:Bundle?){}
                override fun onEvent(e:Int,b:Bundle?){}
            })
            recognizer.startListening(android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"es-EC");putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true)})
        }
    }
    private fun refresh(){setInputView(buildKeyboard())}
    override fun onDestroy(){speech?.destroy();super.onDestroy()}
}
