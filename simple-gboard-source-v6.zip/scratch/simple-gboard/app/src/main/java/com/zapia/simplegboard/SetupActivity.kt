package com.zapia.simplegboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SetupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val voicePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
            SetupScreen(
                onEnable = { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) },
                onChoose = { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() },
                onVoice = { voicePermission.launch(Manifest.permission.RECORD_AUDIO) },
                voiceGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
                askVoice = intent.getBooleanExtra("request_voice", false)
            )
        }
    }
}
@Composable private fun SetupScreen(onEnable:()->Unit,onChoose:()->Unit,onVoice:()->Unit,voiceGranted:Boolean,askVoice:Boolean){
    LaunchedEffect(askVoice) { if (askVoice) onVoice() }
    val dark=Color(0xFF080A0D);val line=Color(0xFFE9EFF5);val green=Color(0xFF9BFFB5)
    MaterialTheme(colorScheme=darkColorScheme(primary=green,background=dark,surface=Color(0xFF11151A),onSurface=line)){
        Column(Modifier.fillMaxSize().background(dark).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
            Text("SIMPLE GBOARD",color=line,fontSize=28.sp,fontWeight=FontWeight.Black)
            Text("Teclado retro, grande y fácil de leer.",color=green,fontSize=16.sp)
            Text("1 · Activa Simple Gboard en los ajustes de teclado de Android.",color=line,fontSize=15.sp)
            Button(onClick=onEnable,modifier=Modifier.fillMaxWidth(),shape=RectangleShape){Text("Abrir ajustes de teclado")}
            Text("2 · Elígelo como teclado predeterminado.",color=line,fontSize=15.sp)
            OutlinedButton(onClick=onChoose,modifier=Modifier.fillMaxWidth(),shape=RectangleShape){Text("Elegir teclado")}
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick=onVoice,modifier=Modifier.fillMaxWidth(),shape=RectangleShape){Text(if(voiceGranted)"Permiso de voz activado" else "Activar permiso de voz",color=if(voiceGranted)green else line)}
            PreviewKeys()
        }
    }
}
@Composable private fun PreviewKeys(){val line=Color(0xFFE9EFF5);val bg=Color(0xFF10151B);Column(verticalArrangement=Arrangement.spacedBy(4.dp)){listOf("1 2 3 4 5 6 7 8 9 0","Q W E R T Y U I O P","A S D F G H J K L","Z X C V B N M").forEach{r->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp)){r.split(" ").forEach{k->Box(Modifier.weight(1f).height(38.dp).background(bg).border(1.dp,line,RectangleShape),contentAlignment=Alignment.Center){Text(k,color=line,fontSize=17.sp,fontWeight=FontWeight.Bold)}}}}}}
