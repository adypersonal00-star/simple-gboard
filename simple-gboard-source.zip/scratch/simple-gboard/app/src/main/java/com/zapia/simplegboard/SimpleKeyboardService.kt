package com.zapia.simplegboard

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.os.Bundle
import android.inputmethodservice.InputMethodService
import android.speech.RecognizerIntent
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RectangleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.setContent
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val KeyboardBg=Color(0xFF080A0D);private val KeyBg=Color(0xFF121820);private val White=Color(0xFFEAF0F6);private val Border=Color(0xFFDCE4EB)

class SimpleKeyboardService:InputMethodService(){
    private var caps=false
    private val panelState= mutableStateOf("letters")
    private var voiceRecognizer: SpeechRecognizer? = null
    private var panel by panelState
    override fun onCreateInputView(): View {
        return ComposeView(this).apply { setContent { KeyboardScreen(panel=panel,caps=caps,onCaps={caps=!caps},onPanel={panel=it},onText={insert(it)},onDelete={delete()},onEnter={enter()},onVoice={launchVoice()}) } }
    }
    private fun insert(text:String){ currentInputConnection?.commitText(text,1) }
    private fun delete(){ currentInputConnection?.deleteSurroundingText(1,0) }
    private fun enter(){val ic=currentInputConnection?:return;val action=currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)?:EditorInfo.IME_ACTION_UNSPECIFIED;when(action){EditorInfo.IME_ACTION_GO,EditorInfo.IME_ACTION_SEARCH,EditorInfo.IME_ACTION_SEND,EditorInfo.IME_ACTION_NEXT->ic.performEditorAction(action);else->ic.commitText("\n",1)}}
    private fun launchVoice(){
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val intent=Intent(this,SetupActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("request_voice",true)
            runCatching { startActivity(intent) }
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        runCatching {
            voiceRecognizer?.destroy()
            voiceRecognizer=SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object:RecognitionListener{
                    override fun onResults(results:Bundle?){results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let{insert(it)}; recognizer.destroy();voiceRecognizer=null}
                    override fun onError(error:Int){recognizer.destroy();voiceRecognizer=null}
                    override fun onReadyForSpeech(params:Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB:Float) {}
                    override fun onBufferReceived(buffer:ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults:Bundle?) {}
                    override fun onEvent(eventType:Int,params:Bundle?) {}
                })
                val request=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"es");putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false)}
                recognizer.startListening(request)
            }
        }
    }
    override fun onDestroy(){voiceRecognizer?.destroy();voiceRecognizer=null;super.onDestroy()}
}

@Composable private fun KeyboardScreen(panel:String,caps:Boolean,onCaps:()->Unit,onPanel:(String)->Unit,onText:(String)->Unit,onDelete:()->Unit,onEnter:()->Unit,onVoice:()->Unit){
    val symbols=listOf("!","@","#","$","%","&","*","(",")","-","_","+","=","/",":",";","?","!","\"","'",".",",","[","]","{","}","\\","~","<",">","€","£")
    val emojis=listOf("😀","😃","😄","😁","😆","😅","😂","🙂","🙃","😉","😊","😍","🥰","😘","😎","🤩","🥳","😭","😢","😡","👍","👎","👏","🙏","❤️","💙","💚","💛","💜","✨","🔥","🎉")
    Column(Modifier.fillMaxWidth().background(KeyboardBg).border(2.dp,Border,RectangleShape).padding(horizontal=4.dp, vertical=4.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(4.dp), verticalAlignment=Alignment.CenterVertically) {
            RetroKey("VOZ",Modifier.weight(1f),"Botón de reconocimiento de voz") { onVoice() }
            RetroKey("ABC",Modifier.weight(1f),"Mostrar letras") { onPanel("letters") }
            RetroKey("123",Modifier.weight(1f),"Mostrar números y símbolos") { onPanel(if(panel=="symbols")"letters" else "symbols") }
            RetroKey("☺",Modifier.weight(1f),"Mostrar emojis") { onPanel(if(panel=="emoji")"letters" else "emoji") }
        }
        if(panel=="emoji") {
            LazyVerticalGrid(columns=GridCells.Fixed(8), modifier=Modifier.fillMaxWidth().heightIn(max=176.dp), horizontalArrangement=Arrangement.spacedBy(2.dp), verticalArrangement=Arrangement.spacedBy(2.dp)) {
                items(emojis){e->RetroKey(e,Modifier.width(36.dp),"Emoji $e"){onText(e)}}
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.End){RetroKey("CERRAR",Modifier.weight(1f),"Cerrar cuadrícula de emojis"){onPanel("letters")};RetroKey("⌫",Modifier.weight(1f),"Eliminar carácter"){onDelete()};RetroKey("ENTER",Modifier.weight(1.5f),"Enter"){onEnter()}}
        } else {
            val numberRow="1234567890".map{it.toString()}
            RetroRow(numberRow,"fila numérica",caps,onText)
            if(panel=="symbols") {
                symbols.chunked(10).forEachIndexed{index,row->RetroRow(row,"símbolos, fila ${index+1}",caps,onText)}
            } else {
                listOf("qwertyuiop","asdfghjkl","zxcvbnm").forEachIndexed{rowIndex,row->RetroRow(row.map{it.toString()},"letras, fila ${rowIndex+1}",caps,onText)}
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(4.dp), verticalAlignment=Alignment.CenterVertically) {
                RetroKey("⇧",Modifier.weight(1f),if(caps)"Cambiar a minúsculas" else "Cambiar a mayúsculas"){onCaps()}
                RetroKey("⌫",Modifier.weight(1f),"Eliminar carácter"){onDelete()}
                RetroKey("ESPACIO",Modifier.weight(4f),"Insertar espacio"){onText(" ")}
                RetroKey("ENTER",Modifier.weight(1.5f),"Enter"){onEnter()}
            }
        }
    }
}

@Composable private fun RetroRow(keys:List<String>,rowName:String,caps:Boolean,onText:(String)->Unit){
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(3.dp), verticalAlignment=Alignment.CenterVertically){
        keys.forEachIndexed{column,key->
            val value=if(key.length==1&&key[0].isLetter()&&caps)key.uppercase()else key
            RetroKey(value,Modifier.weight(1f),"$rowName, columna ${column+1}, tecla $value"){onText(value)}
        }
    }
}

@Composable private fun RetroKey(label:String,modifier:Modifier,description:String,onClick:()->Unit){
    Box(modifier.height(44.dp).background(KeyBg,RectangleShape).border(1.dp,Border,RectangleShape).clickable{onClick()}.semantics{contentDescription=description},contentAlignment=Alignment.Center){
        Text(label,color=White,fontSize=if(label.length>3)11.sp else 20.sp,fontWeight=FontWeight.Bold,maxLines=1)
    }
}

private fun colorRoleTint(panel: String): Color = if(panel=="emoji") Green else White
