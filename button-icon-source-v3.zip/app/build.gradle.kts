plugins { id("com.android.application") }

android {
    namespace = "com.buttonicon.pack"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.buttonicon.pack"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
