package com.buttonicon.pack;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(8, 10, 15));
    getWindow().setNavigationBarColor(Color.rgb(8, 10, 15));
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setGravity(Gravity.CENTER);
    root.setPadding(28, 32, 28, 32);
    root.setBackgroundColor(Color.rgb(8, 10, 15));
    ImageView art = new ImageView(this);
    art.setImageResource(R.drawable.button_icon);
    art.setContentDescription("Vista previa de Button Icon: icono circular con relieve y aro negro");
    root.addView(art, new LinearLayout.LayoutParams(220, 220));
    TextView title = new TextView(this);
    title.setText(getString(R.string.title)); title.setTextSize(28); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER); title.setPadding(0, 24, 0, 8);
    root.addView(title, new LinearLayout.LayoutParams(-1, -2));
    TextView desc = new TextView(this);
    desc.setText(getString(R.string.subtitle)); desc.setTextSize(16); desc.setTextColor(Color.rgb(195, 205, 220)); desc.setGravity(Gravity.CENTER); desc.setPadding(0, 0, 0, 20);
    root.addView(desc, new LinearLayout.LayoutParams(-1, -2));
    TextView instructions = new TextView(this);
    instructions.setText(getString(R.string.instructions)); instructions.setTextSize(15); instructions.setTextColor(Color.rgb(232, 236, 244)); instructions.setLineSpacing(5, 1f);
    root.addView(instructions, new LinearLayout.LayoutParams(-1, -2));
    setContentView(root);
  }
}
