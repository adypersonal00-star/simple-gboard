plugins { id("com.android.application") }
android {
 namespace = "com.zapia.bootshow"
 compileSdk = 35
 defaultConfig { applicationId = "com.zapia.bootshow"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "1.1" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 signingConfigs {
  create("stableRelease") {
   storeFile = rootProject.file("boot-show-release.p12")
   storeType = "PKCS12"
   storePassword = System.getenv("BOOT_SHOW_KEYSTORE_PASSWORD")
   keyAlias = "boot-show-release"
   keyPassword = System.getenv("BOOT_SHOW_KEYSTORE_PASSWORD")
  }
 }
 buildTypes {
  getByName("release") {
   signingConfig = signingConfigs.getByName("stableRelease")
  }
 }
}
