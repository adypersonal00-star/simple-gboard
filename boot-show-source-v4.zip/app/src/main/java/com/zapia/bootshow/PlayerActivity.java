package com.zapia.bootshow;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Plays Android bootanimation.zip / shutdownanimation.zip archives (desc.txt, PNG parts, optional per-part audio.wav). */
public class PlayerActivity extends Activity {
    private final Handler handler = new Handler();
    private FrameLayout root;
    private ImageView image;
    private TextView error;
    private Uri sourceUri, externalAudio;
    private int brightness, orientationChoice, fps = 24, partIndex, frameIndex, partLoops;
    private boolean stopped;
    private final ArrayList<Part> parts = new ArrayList<>();
    private MediaPlayer sound;
    private Runnable ticker;

    private static class Part {
        String directory;
        int count = 1, pause = 0;
        final ArrayList<byte[]> frames = new ArrayList<>();
        byte[] audio;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        String uri = getIntent().getStringExtra("uri");
        sourceUri = Uri.parse(uri);
        brightness = getIntent().getIntExtra("brightness", 0);
        orientationChoice = getIntent().getIntExtra("orientation", 0);
        String audio = getIntent().getStringExtra("audio");
        if (audio != null) externalAudio = Uri.parse(audio);
        applyFullscreen();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = brightness == 0 ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : brightness / 100f;
        getWindow().setAttributes(lp);
        build();
        readAnimationZip();
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    private void applyFullscreen() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void build() {
        root = new FrameLayout(this);
        root.setBackgroundColor(0xff000000);
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(image, new FrameLayout.LayoutParams(-1, -1));
        error = new TextView(this);
        error.setTextColor(0xffffffff);
        error.setTextSize(16);
        error.setGravity(Gravity.CENTER);
        error.setPadding(dp(26), dp(18), dp(26), dp(18));
        error.setBackgroundColor(0xcc000000);
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(error, ep);
        error.setVisibility(View.GONE);
        setContentView(root);
    }

    private void readAnimationZip() {
        try (InputStream raw = getContentResolver().openInputStream(sourceUri);
             ZipInputStream zip = new ZipInputStream(raw)) {
            if (zip == null) throw new Exception("No se pudo abrir el ZIP");
            Map<String, byte[]> entries = new HashMap<>();
            long totalBytes = 0;
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String name = entry.getName();
                String lower = name.toLowerCase(Locale.ROOT);
                if (!(lower.endsWith(".png") || lower.endsWith(".wav") || lower.equals("desc.txt"))) continue;
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[32768];
                int size;
                while ((size = zip.read(buffer)) > 0) {
                    totalBytes += size;
                    if (totalBytes > 160L * 1024 * 1024) throw new Exception("El ZIP supera el límite de tamaño para reproducirlo");
                    out.write(buffer, 0, size);
                }
                entries.put(name, out.toByteArray());
            }
            byte[] desc = entries.get("desc.txt");
            if (desc == null) throw new Exception("No contiene desc.txt; selecciona un bootanimation.zip o shutdownanimation.zip de Android");
            parseDescription(new String(desc, java.nio.charset.StandardCharsets.UTF_8), entries);
            if (parts.isEmpty()) throw new Exception("No encontré fotogramas PNG dentro de las partes descritas en desc.txt");
            int[] canvas = canvasSize(new String(desc, java.nio.charset.StandardCharsets.UTF_8), parts.get(0).frames.get(0));
            chooseOrientation(canvas[0], canvas[1]);
            if (externalAudio != null) playExternalAudio();
            beginPart(0);
        } catch (Exception e) {
            showError("No pude reproducir este ZIP de animación Android: " + e.getMessage());
        }
    }

    private void parseDescription(String description, Map<String, byte[]> entries) {
        String[] lines = description.split("\\r?\\n");
        if (lines.length == 0) return;
        String[] header = lines[0].trim().split("\\s+");
        int width = 0, height = 0;
        try {
            width = Integer.parseInt(header[0]);
            height = Integer.parseInt(header[1]);
            if (header.length > 2) fps = Math.max(1, Math.min(60, Integer.parseInt(header[2])));
        } catch (Exception ignored) { }
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] fields = line.split("\\s+");
            if (fields.length < 4 || !(fields[0].equals("p") || fields[0].equals("c") || fields[0].equals("f"))) continue;
            Part part = new Part();
            try { part.count = Integer.parseInt(fields[1]); part.pause = Integer.parseInt(fields[2]); }
            catch (Exception ignored) { continue; }
            part.directory = fields[3].endsWith("/") ? fields[3] : fields[3] + "/";
            ArrayList<String> names = new ArrayList<>();
            for (String name : entries.keySet()) {
                if (name.startsWith(part.directory) && name.toLowerCase(Locale.ROOT).endsWith(".png")) names.add(name);
                if (name.equalsIgnoreCase(part.directory + "audio.wav")) part.audio = entries.get(name);
            }
            Collections.sort(names);
            for (String name : names) part.frames.add(entries.get(name));
            if (!part.frames.isEmpty()) parts.add(part);
        }
        if (width <= 0 || height <= 0) {
            int[] actual = dimensions(parts.isEmpty() ? null : parts.get(0).frames.get(0));
            width = actual[0]; height = actual[1];
        }
        // Store canvas values in the activity fields for reliable orientation selection.
        canvasWidth = width; canvasHeight = height;
    }

    private int canvasWidth, canvasHeight;
    private int[] canvasSize(String ignored, byte[] firstFrame) {
        if (canvasWidth > 0 && canvasHeight > 0) return new int[]{canvasWidth, canvasHeight};
        return dimensions(firstFrame);
    }

    private int[] dimensions(byte[] bytes) {
        if (bytes == null) return new int[]{0, 0};
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        return new int[]{options.outWidth, options.outHeight};
    }

    private void chooseOrientation(int width, int height) {
        if (orientationChoice == 1) { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); return; }
        if (orientationChoice == 2) { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); return; }
        if (width > 0 && height > 0) {
            setRequestedOrientation(height >= width ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            return;
        }
        new android.app.AlertDialog.Builder(this).setTitle("Elige orientación")
                .setMessage("El ZIP no indica si la animación es vertical u horizontal.")
                .setPositiveButton("Vertical", (d, which) -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT))
                .setNegativeButton("Horizontal", (d, which) -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE))
                .setOnCancelListener(d -> finish()).show();
    }

    private void beginPart(int index) {
        if (stopped || parts.isEmpty()) return;
        if (index >= parts.size()) index = 0; // repeat the complete animation in a loop
        partIndex = index;
        Part part = parts.get(partIndex);
        frameIndex = 0;
        partLoops = 0;
        if (externalAudio == null) playPartAudio(part.audio);
        displayFrame(part.frames.get(0));
        if (ticker != null) handler.removeCallbacks(ticker);
        ticker = new Runnable() {
            @Override public void run() {
                if (stopped) return;
                frameIndex++;
                if (frameIndex >= part.frames.size()) {
                    partLoops++;
                    int wantedLoops = part.count <= 0 ? 1 : Math.max(1, part.count);
                    if (partLoops < wantedLoops) frameIndex = 0;
                    else { beginPart(partIndex + 1); return; }
                }
                displayFrame(part.frames.get(frameIndex));
                handler.postDelayed(this, Math.max(1, 1000 / fps));
            }
        };
        handler.postDelayed(ticker, Math.max(1, 1000 / fps));
    }

    private void displayFrame(byte[] data) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        int width = root.getWidth(), height = root.getHeight();
        if (width <= 1 || height <= 1) {
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            width = metrics.widthPixels; height = metrics.heightPixels;
        }
        int sample = 1;
        while (bounds.outWidth / sample > width * 1.5 || bounds.outHeight / sample > height * 1.5) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
        if (bitmap != null) image.setImageBitmap(bitmap);
    }

    private void playPartAudio(byte[] bytes) {
        stopSound();
        if (bytes == null) return;
        try {
            File wav = new File(getCacheDir(), "boot-part-audio.wav");
            try (FileOutputStream output = new FileOutputStream(wav)) { output.write(bytes); }
            sound = new MediaPlayer();
            sound.setDataSource(wav.getAbsolutePath());
            sound.setOnPreparedListener(MediaPlayer::start);
            sound.prepareAsync();
        } catch (Exception ignored) { }
    }

    private void playExternalAudio() {
        try {
            sound = new MediaPlayer();
            sound.setDataSource(this, externalAudio);
            sound.setLooping(true);
            sound.setOnPreparedListener(MediaPlayer::start);
            sound.prepareAsync();
        } catch (Exception e) {
            Toast.makeText(this, "No pude reproducir el WAV seleccionado", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopSound() {
        if (sound != null) {
            try { sound.stop(); } catch (Exception ignored) { }
            sound.release(); sound = null;
        }
    }

    private void showError(String message) {
        error.setText(message + "\n\nToca la pantalla para salir.");
        error.setVisibility(View.VISIBLE);
        root.setOnClickListener(v -> finish());
    }

    @Override public void onWindowFocusChanged(boolean focused) { super.onWindowFocusChanged(focused); if (focused) applyFullscreen(); }
    @Override protected void onDestroy() {
        stopped = true;
        if (ticker != null) handler.removeCallbacks(ticker);
        stopSound();
        super.onDestroy();
    }
}
