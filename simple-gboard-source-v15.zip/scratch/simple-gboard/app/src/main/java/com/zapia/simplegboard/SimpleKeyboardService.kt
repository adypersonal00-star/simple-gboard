package com.zapia.simplegboard

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView

/** Native Android views are used for the IME surface so it can be inflated reliably by InputMethodService. */
class SimpleKeyboardService : InputMethodService() {
    private var caps = false
    private var panel = "letters"
    private var speech: SpeechRecognizer? = null
    private val bg = Color.rgb(8, 10, 13)
    private val keyBg = Color.rgb(18, 24, 32)
    private val fg = Color.rgb(234, 240, 246)
    private val stroke = Color.rgb(220, 228, 235)
    private val gap = 3

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        caps = false
        panel = "letters"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + .5f).toInt()

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            contentDescription = "Simple Gboard"
        }
        if (panel == "emoji") {
            addToolbar(root)
            addGrid(root, listOf("😀","😃","😄","😁","😆","😅","😂","🙂","🙃","😉","😊","😍","🥰","😘","😎","🤩","🥳","😭","😢","😡","👍","👎","👏","🙏","❤️","💙","💚","💛","💜","✨","🔥","🎉"), 8)
            addRow(root, listOf("CERRAR", "BORRAR", "ENTER"), listOf({ panel="letters"; refresh() }, { delete() }, { enter() }), listOf(1f,1f,1f), 44)
        } else {
            addToolbar(root)
            addRow(root, "1234567890".map { it.toString() }, "1234567890".map { value -> { insert(value) } }, height=38)
            if (panel == "symbols") {
                val chars = listOf("!","@","#","$","%","&","*","(",")","-","_","+","=","/",":",";","?","\"","'",".",",","[","]","{","}","\\","~","<",">","€","£")
                chars.chunked(10).forEach { row -> addRow(root, row, row.map { value -> { insert(value) } }, height=43) }
            } else {
                addLetterRow(root, "qwertyuiop", 1)
                addLetterRow(root, "asdfghjkl", 2)
                addLetterRow(root, "zxcvbnm", 3)
            }
            addRow(root, listOf("⇧", "BORRAR", "ESPACIO", "ENTER"), listOf({ caps=!caps;refresh() }, { delete() }, { insert(" ") }, { enter() }), listOf(1f,1.35f,3.5f,1.35f), 48)
        }
        return root
    }

    private fun refresh() { setInputView(buildKeyboard()) }

    private fun addToolbar(root: LinearLayout) {
        addRow(root, listOf("VOZ", "ABC", "123", "☺"), listOf({ voice() }, { panel="letters";refresh() }, { panel=if(panel=="symbols")"letters" else "symbols";refresh() }, { panel=if(panel=="emoji")"letters" else "emoji";refresh() }), listOf(1f,1f,1f,1f), 42)
    }

    private fun addLetterRow(root: LinearLayout, letters: String, rowNumber: Int) {
        val keys = letters.map { if(caps) it.uppercaseChar().toString() else it.toString() }
        val actions = keys.map { value -> { insert(value) } }
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,dp(1),0,dp(1)) }
        keys.forEachIndexed { index, label ->
            val button = makeKey(label, "Fila $rowNumber, columna ${index+1}, tecla $label", actions[index])
            row.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(1),0,dp(1),0) })
        }
        root.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)))
    }

    private fun addGrid(root: LinearLayout, items: List<String>, columns: Int) {
        val scroll = ScrollView(this).apply { isFillViewport=false; overScrollMode=View.OVER_SCROLL_NEVER }
        val grid = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        items.chunked(columns).forEachIndexed { rowIndex, rowItems ->
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
            rowItems.forEachIndexed { col, item ->
                row.addView(makeKey(item,"Emoji, fila ${rowIndex+1}, columna ${col+1}: $item") { insert(item) }, LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(dp(1),dp(1),dp(1),dp(1))})
            }
            grid.addView(row,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(44)))
        }
        scroll.addView(grid)
        root.addView(scroll,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(180)))
    }

    private fun addRow(root: LinearLayout, labels: List<String>, actions: List<() -> Unit>, weights: List<Float>? = null, height: Int = 44) {
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(0,dp(1),0,dp(1))}
        labels.forEachIndexed{index,label->
            val weight=weights?.get(index)?:1f
            row.addView(makeKey(label,"${labels.getOrNull(index) ?: label}",actions[index]),LinearLayout.LayoutParams(0,dp(height),weight).apply{setMargins(dp(1),0,dp(1),0)})
        }
        root.addView(row,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(height+2)))
    }

    private fun makeKey(label:String, description:String, action:()->Unit):Button = Button(this).apply{
        text=label
        contentDescription=description
        setTextColor(fg)
        textSize=if(label.length>4)11f else 20f
        typeface=Typeface.DEFAULT_BOLD
        isAllCaps=false
        minWidth=0;minimumWidth=0;minHeight=0;minimumHeight=0
        setPadding(dp(2),0,dp(2),0)
        background=GradientDrawable().apply{shape=GradientDrawable.RECTANGLE;setColor(keyBg);setStroke(dp(1),stroke);cornerRadius=0f}
        setOnClickListener{action()}
    }

    private fun insert(text:String){currentInputConnection?.commitText(text,1)}
    private fun delete(){currentInputConnection?.deleteSurroundingText(1,0)}
    private fun enter(){
        val ic=currentInputConnection?:return
        val action=currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)?:EditorInfo.IME_ACTION_UNSPECIFIED
        when(action){EditorInfo.IME_ACTION_GO,EditorInfo.IME_ACTION_SEARCH,EditorInfo.IME_ACTION_SEND,EditorInfo.IME_ACTION_NEXT,EditorInfo.IME_ACTION_DONE->ic.performEditorAction(action);else->ic.commitText("\n",1)}
    }
    private fun voice(){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){startActivity(android.content.Intent(this,SetupActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("request_voice",true));return}
        if(!SpeechRecognizer.isRecognitionAvailable(this))return
        runCatching{
            speech?.destroy()
            speech=SpeechRecognizer.createSpeechRecognizer(this).also{ recognizer->
                recognizer.setRecognitionListener(object:RecognitionListener{
                    override fun onResults(results:Bundle?){results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let{insert(it)};recognizer.destroy();speech=null}
                    override fun onError(error:Int){recognizer.destroy();speech=null}
                    override fun onReadyForSpeech(params:Bundle?){};override fun onBeginningOfSpeech(){};override fun onRmsChanged(rmsdB:Float){};override fun onBufferReceived(buffer:ByteArray?){};override fun onEndOfSpeech(){};override fun onPartialResults(partialResults:Bundle?){};override fun onEvent(eventType:Int,params:Bundle?){}
                })
                recognizer.startListening(android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"es")})
            }
        }
    }
    override fun onDestroy(){speech?.destroy();speech=null;super.onDestroy()}
}
