package com.zapia.simplegboard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SetupActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{
  val p=getSharedPreferences("ai_keyboard",MODE_PRIVATE)
  var testText by remember{mutableStateOf("")}
  val voiceLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
  val gifPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){runCatching{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)};p.edit().putString("pending_gif_uri",uri.toString()).apply();finish()}}
  var bg by remember{mutableIntStateOf(p.getInt("bg",0xFF0D121C.toInt()))};var key by remember{mutableIntStateOf(p.getInt("key",0xFF1E293B.toInt()))};var fg by remember{mutableIntStateOf(p.getInt("fg",Color.White))};var border by remember{mutableIntStateOf(p.getInt("border",0xFF5F738C.toInt()))}
  var round by remember{mutableStateOf(p.getBoolean("round",true))};var blocks by remember{mutableStateOf(p.getBoolean("square_font",false))};var h by remember{mutableFloatStateOf(p.getInt("height",66).toFloat())}
  LaunchedEffect(intent.getBooleanExtra("pick_gif",false)){if(intent.getBooleanExtra("pick_gif",false))gifPicker.launch(arrayOf("image/gif"))}
  val saved= {p.edit().putInt("bg",bg).putInt("key",key).putInt("fg",fg).putInt("border",border).putBoolean("round",round).putBoolean("square_font",blocks).putInt("height",h.toInt()).apply()}
  MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF8ED7FF),background=Color(0xFF0D121C),surface=Color(0xFF1E293B),onSurface=Color.White)){
   Column(Modifier.fillMaxSize().background(Color(0xFF0D121C)).verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    Text("AI Keyboard",fontSize=28.sp,fontWeight=FontWeight.Black,color=Color.White)
    Text("Teclado Android nativo · tus pulsaciones y texto no se envían a servidores.",color=Color(0xFFBAD0E6))
    Button(onClick={startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))},modifier=Modifier.fillMaxWidth()){Text("Activar teclado")}
    OutlinedButton(onClick={(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()},modifier=Modifier.fillMaxWidth()){Text("Elegir AI Keyboard")}
    OutlinedTextField(value=testText,onValueChange={testText=it},label={Text("Prueba el teclado aquí")},modifier=Modifier.fillMaxWidth())
    OutlinedButton(onClick={if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)voiceLauncher.launch(Manifest.permission.RECORD_AUDIO) else {}},modifier=Modifier.fillMaxWidth()){Text(if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)"Dictado: permiso activado" else "Permitir dictado")}
    HorizontalDivider();Text("Aspecto del teclado",fontWeight=FontWeight.Bold)
    Row(verticalAlignment=Alignment.CenterVertically){Text("Teclas redondeadas",Modifier.weight(1f));Switch(round,{round=it;saved()})}
    Row(verticalAlignment=Alignment.CenterVertically){Text("Letras en bloques Unicode",Modifier.weight(1f));Switch(blocks,{blocks=it;saved()})}
    Text("Altura: ${h.toInt()} dp");Slider(h,{h=it;saved()},valueRange=56f..80f)
    colorChoice("Fondo del teclado",bg,listOf(0xFF0D121C.toInt(),0xFF000000.toInt(),0xFF263238.toInt(),0xFF263A50.toInt())){bg=it;saved()}
    colorChoice("Fondo de teclas",key,listOf(0xFF1E293B.toInt(),0xFF333333.toInt(),0xFF243B53.toInt(),0xFF444444.toInt())){key=it;saved()}
    colorChoice("Color de letras",fg,listOf(Color.White,0xFF8ED7FF.toInt(),0xFFFFE082.toInt(),0xFFB8F28B.toInt())){fg=it;saved()}
    colorChoice("Contorno de teclas",border,listOf(0xFF5F738C.toInt(),Color.White,0xFF8ED7FF.toInt(),0xFF000000.toInt())){border=it;saved()}
    HorizontalDivider();Text("Formato al escribir",fontWeight=FontWeight.Bold)
    Text("La corrección muestra sugerencias del corrector Android; no cambia ni envía el texto por sí sola. El modelo Qwen aún no está descargado; el reconocimiento de dibujos usa plantillas locales y no se presenta como IA.",fontSize=13.sp,color=Color(0xFFBAD0E6))
   }
  }
 }}
}
@Composable private fun colorChoice(title:String,selected:Int,options:List<Int>,onSelect:(Int)->Unit){Column{Text(title,fontSize=13.sp,color=Color(0xFFBAD0E6));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){options.forEach{c->Box(Modifier.size(34.dp).background(Color(c),RoundedCornerShape(8.dp)).border(if(selected==c)3.dp else 1.dp,Color.White,RoundedCornerShape(8.dp)).clickable{onSelect(c)})}}}}
