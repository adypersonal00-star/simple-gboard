package com.zapia.simpleplayer;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO=402;
    private final int BG=Color.rgb(9,11,16), PANEL=Color.rgb(20,24,33), ORANGE=Color.rgb(255,153,0), WHITE=Color.WHITE, MUTED=Color.rgb(175,184,198);
    private final ArrayList<Track> tracks=new ArrayList<>();
    private final Handler handler=new Handler();
    private MediaPlayer player;
    private int current=-1;
    private boolean repeat=false, shuffle=false, dragging=false, blink=true;
    private LinearLayout root, listView;
    private TextView title, artist, playButton, repeatButton, shuffleButton, timeLabel;
    private SeekBar seek;
    private ImageView cover;
    private View placeholder;
    private Runnable ticker;
    private static class Track {
        long id, albumId, duration;
        String title, artist;
        Uri uri;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);Window w=getWindow();w.setStatusBarColor(BG);w.setNavigationBarColor(BG);checkPermission();}
    private String permission(){return Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;}
    private void checkPermission(){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(permission())!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{permission()},REQ_AUDIO);else loadLibrary();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_AUDIO){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)loadLibrary();else showPermissionMessage();}}
    private void showPermissionMessage(){root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER);root.setPadding(dp(28),dp(24),dp(28),dp(24));root.setBackgroundColor(BG);TextView t=text("Simple Player",26,WHITE,true);t.setGravity(Gravity.CENTER);root.addView(t);TextView m=text("Para mostrar y reproducir la música del teléfono, permite el acceso a archivos de audio.",17,MUTED,false);m.setGravity(Gravity.CENTER);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(20);root.addView(m,mp);Button b=button("Permitir acceso",ORANGE,Color.BLACK);b.setOnClickListener(v->checkPermission());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(56));bp.topMargin=dp(22);root.addView(b,bp);setContentView(root);}
    private void loadLibrary(){tracks.clear();Uri collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM_ID,MediaStore.Audio.Media.DURATION};String selection=MediaStore.Audio.Media.IS_MUSIC+" != 0";try(Cursor c=getContentResolver().query(collection,projection,selection,null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")){if(c!=null)while(c.moveToNext()){Track t=new Track();t.id=c.getLong(0);t.title=clean(c.getString(1),"Sin título");t.artist=clean(c.getString(2),"Artista desconocido");t.albumId=c.getLong(3);t.duration=c.getLong(4);t.uri=ContentUris.withAppendedId(collection,t.id);tracks.add(t);}}catch(Exception e){Toast.makeText(this,"No se pudo leer la biblioteca de audio",Toast.LENGTH_LONG).show();}showLibrary();}
    private String clean(String s,String fallback){return s==null||s.trim().isEmpty()||s.equals("<unknown>")?fallback:s;}
    private void showLibrary(){root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(16),dp(18),dp(8));LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView h=text("SIMPLE PLAYER",24,WHITE,true);head.addView(h,new LinearLayout.LayoutParams(0,-2,1));TextView count=text(tracks.size()+" canciones",13,MUTED,false);head.addView(count);root.addView(head);TextView sub=text("TU MÚSICA",12,ORANGE,true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(7);sp.bottomMargin=dp(10);root.addView(sub,sp);android.widget.ScrollView scroll=new android.widget.ScrollView(this);listView=new LinearLayout(this);listView.setOrientation(1);scroll.addView(listView);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));if(tracks.isEmpty()){TextView empty=text("No encontré canciones en el dispositivo. Agrega archivos de audio y vuelve a abrir la app.",16,MUTED,false);empty.setGravity(Gravity.CENTER);listView.addView(empty,new LinearLayout.LayoutParams(-1,dp(180)));}else for(int i=0;i<tracks.size();i++)addTrackRow(i);setContentView(root);}
    private void addTrackRow(int index){Track t=tracks.get(index);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(9),dp(8),dp(10),dp(8));row.setBackground(round(PANEL,dp(14),Color.TRANSPARENT,0));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(68));rp.bottomMargin=dp(7);listView.addView(row,rp);ImageView icon=new ImageView(this);icon.setImageResource(android.R.drawable.ic_media_play);icon.setColorFilter(ORANGE);icon.setContentDescription("Icono de música");row.addView(icon,new LinearLayout.LayoutParams(dp(36),dp(36)));LinearLayout texts=new LinearLayout(this);texts.setOrientation(1);texts.setPadding(dp(12),0,0,0);row.addView(texts,new LinearLayout.LayoutParams(0,-2,1));TextView n=text(t.title,16,WHITE,true);n.setSingleLine(true);n.setEllipsize(android.text.TextUtils.TruncateAt.END);texts.addView(n);TextView a=text(t.artist,13,MUTED,false);a.setSingleLine(true);a.setEllipsize(android.text.TextUtils.TruncateAt.END);texts.addView(a);TextView arrow=text("▶",17,ORANGE,true);row.addView(arrow);row.setContentDescription("Reproducir "+t.title+", "+t.artist);row.setOnClickListener(v->play(index));}
    private void showPlayer(){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(20),dp(12),dp(20),dp(10));root.setBackgroundColor(BG);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView back=text("‹",38,WHITE,true);back.setContentDescription("Volver a la lista de canciones");back.setOnClickListener(v->showLibrary());top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));TextView label=text("REPRODUCIENDO",13,MUTED,true);label.setGravity(Gravity.CENTER);top.addView(label,new LinearLayout.LayoutParams(0,-2,1));TextView menu=text("⋮",28,WHITE,true);menu.setContentDescription("Más opciones");top.addView(menu,new LinearLayout.LayoutParams(dp(40),dp(48)));root.addView(top,new LinearLayout.LayoutParams(-1,dp(50)));
        FrameLayout artFrame=new FrameLayout(this);artFrame.setBackground(round(PANEL,dp(22),Color.rgb(39,43,52),dp(1)));cover=new ImageView(this);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-1);cp.setMargins(dp(1),dp(1),dp(1),dp(1));artFrame.addView(cover,cp);placeholder=makePlaceholder();artFrame.addView(placeholder,new FrameLayout.LayoutParams(-1,-1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,0,5.2f);ap.topMargin=dp(10);ap.bottomMargin=dp(18);root.addView(artFrame,ap);
        title=text("",22,WHITE,true);title.setGravity(Gravity.CENTER);title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);title.setMarqueeRepeatLimit(-1);title.setSelected(true);root.addView(title,new LinearLayout.LayoutParams(-1,dp(35)));artist=text("",16,MUTED,false);artist.setGravity(Gravity.CENTER);artist.setSingleLine(true);artist.setEllipsize(android.text.TextUtils.TruncateAt.END);root.addView(artist,new LinearLayout.LayoutParams(-1,dp(28)));
        seek=new SeekBar(this);seek.setMax(1000);seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ORANGE));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(WHITE));seek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(69,73,80)));root.addView(seek,new LinearLayout.LayoutParams(-1,dp(38)));seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){if(u&&player!=null&&player.getDuration()>0)timeLabel.setText(fmt(player.getDuration()*p/1000)+"  /  "+fmt(player.getDuration()));}public void onStartTrackingTouch(SeekBar s){dragging=true;}public void onStopTrackingTouch(SeekBar s){dragging=false;if(player!=null&&player.getDuration()>0)player.seekTo((int)(player.getDuration()*s.getProgress()/1000));}});
        timeLabel=text("0:00  /  0:00",12,MUTED,false);timeLabel.setGravity(Gravity.CENTER);root.addView(timeLabel,new LinearLayout.LayoutParams(-1,dp(20)));
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);controls.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams controlsP=new LinearLayout.LayoutParams(-1,0,2.3f);controlsP.topMargin=dp(8);root.addView(controls,controlsP);
        repeatButton=text("⟳",26,repeat?ORANGE:MUTED,true);repeatButton.setGravity(Gravity.CENTER);repeatButton.setContentDescription("Repetir desactivado");repeatButton.setOnClickListener(v->{repeat=!repeat;updateToggles();});controls.addView(repeatButton,new LinearLayout.LayoutParams(0,-1,1));
        addControl(controls,"−10","Retroceder diez segundos",()->seekBy(-10000),1);
        addControl(controls,"|◀","Canción anterior",()->previous(),1);
        FrameLayout main=new FrameLayout(this);main.setContentDescription("Reproducir o pausar");main.setBackground(round(Color.TRANSPARENT,dp(64),ORANGE,dp(2)));playButton=text("▶",31,ORANGE,true);playButton.setGravity(Gravity.CENTER);main.addView(playButton,new FrameLayout.LayoutParams(-1,-1));main.setOnClickListener(v->toggle());controls.addView(main,new LinearLayout.LayoutParams(0,dp(66),1.5f));
        addControl(controls,"+10","Adelantar diez segundos",()->seekBy(10000),1);
        addControl(controls,"▶|","Siguiente canción",()->next(),1);
        shuffleButton=text("⤨",25,shuffle?ORANGE:MUTED,true);shuffleButton.setGravity(Gravity.CENTER);shuffleButton.setContentDescription("Aleatorio desactivado");shuffleButton.setOnClickListener(v->{shuffle=!shuffle;updateToggles();});controls.addView(shuffleButton,new LinearLayout.LayoutParams(0,-1,1));setContentView(root);loadCover();updatePlayButton();updateToggles();startTicker();}
    private View makePlaceholder(){FrameLayout frame=new FrameLayout(this);GradientDrawable orange=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(255,166,0),Color.rgb(235,91,0)});orange.setCornerRadius(dp(20));frame.setBackground(orange);FrameLayout inner=new FrameLayout(this);inner.setBackground(round(Color.rgb(255,255,255),dp(300),Color.TRANSPARENT,0));FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(dp(148),dp(148),Gravity.CENTER);frame.addView(inner,ip);TextView note=text("♫",74,Color.rgb(255,143,0),true);note.setGravity(Gravity.CENTER);inner.addView(note,new FrameLayout.LayoutParams(-1,-1));return frame;}
    private void loadCover(){if(current<0||current>=tracks.size())return;Track t=tracks.get(current);boolean found=false;if(t.albumId>0){Uri u=ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"),t.albumId);try{cover.setImageURI(u);found=cover.getDrawable()!=null;}catch(Exception ignored){}}cover.setVisibility(found?View.VISIBLE:View.GONE);placeholder.setVisibility(found?View.GONE:View.VISIBLE);if(!found)placeholder.animate().rotationBy(360).setDuration(14000).start();}
    private void play(int i){if(i<0||i>=tracks.size())return;release();current=i;try{player=new MediaPlayer();player.setDataSource(this,tracks.get(i).uri);player.setOnPreparedListener(mp->{mp.start();showPlayer();});player.setOnCompletionListener(mp->{if(repeat){mp.seekTo(0);mp.start();}else next();});player.setOnErrorListener((mp,w,e)->{Toast.makeText(this,"No se pudo reproducir este archivo",Toast.LENGTH_SHORT).show();next();return true;});player.prepareAsync();}catch(Exception e){Toast.makeText(this,"No se pudo abrir la canción",Toast.LENGTH_SHORT).show();}}
    private void release(){stopTicker();if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}}
    private void toggle(){if(player==null){if(current<0&&!tracks.isEmpty())play(0);return;}if(player.isPlaying())player.pause();else player.start();updatePlayButton();}
    private void updatePlayButton(){if(playButton==null)return;boolean playing=player!=null&&player.isPlaying();playButton.setText(playing?"▶":"■");playButton.setContentDescription(playing?"Pausar reproducción":"Reanudar reproducción");}
    private void updateToggles(){if(repeatButton!=null){repeatButton.setTextColor(repeat?ORANGE:MUTED);repeatButton.setContentDescription("Repetir "+(repeat?"activado":"desactivado"));}if(shuffleButton!=null){shuffleButton.setTextColor(shuffle?ORANGE:MUTED);shuffleButton.setContentDescription("Aleatorio "+(shuffle?"activado":"desactivado"));}}
    private void addControl(LinearLayout p,String glyph,String desc,Runnable action,float weight){TextView b=text(glyph,16,WHITE,true);b.setGravity(Gravity.CENTER);b.setContentDescription(desc);b.setOnClickListener(v->action.run());p.addView(b,new LinearLayout.LayoutParams(0,-1,weight));}
    private void seekBy(int amount){if(player!=null){int pos=Math.max(0,Math.min(player.getDuration(),player.getCurrentPosition()+amount));player.seekTo(pos);}}
    private void previous(){if(current<0)return;if(player!=null&&player.getCurrentPosition()>3000){player.seekTo(0);return;}play(Math.max(0,current-1));}
    private void next(){if(tracks.isEmpty())return;int n;if(shuffle&&tracks.size()>1){do{n=new Random().nextInt(tracks.size());}while(n==current);}else n=(current+1)%tracks.size();play(n);}
    private void startTicker(){stopTicker();ticker=new Runnable(){public void run(){if(player!=null&&seek!=null){if(!dragging&&player.getDuration()>0)seek.setProgress((int)(1000L*player.getCurrentPosition()/player.getDuration()));timeLabel.setText(fmt(player.getCurrentPosition())+"  /  "+fmt(player.getDuration()));updatePlayButton();}if(title!=null){blink=!blink;title.setAlpha(blink?1f:.82f);}handler.postDelayed(this,500);}};handler.post(ticker);}
    private void stopTicker(){if(ticker!=null)handler.removeCallbacks(ticker);ticker=null;}
    private String fmt(long ms){long s=Math.max(0,ms/1000);return (s/60)+":"+String.format(java.util.Locale.US,"%02d",s%60);}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);t.setTypeface(Typeface.create("monospace",bold?Typeface.BOLD:Typeface.NORMAL));t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private Button button(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setBackground(round(bg,dp(16),Color.TRANSPARENT,0));return b;}
    private GradientDrawable round(int color,int radius,int stroke,int sw){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(sw>0)d.setStroke(sw,stroke);return d;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override protected void onDestroy(){release();super.onDestroy();}
}
