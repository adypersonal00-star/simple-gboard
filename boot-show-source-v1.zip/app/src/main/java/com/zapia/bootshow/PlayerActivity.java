package com.zapia.bootshow;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;
import android.content.DialogInterface;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class PlayerActivity extends Activity {
 final Handler handler=new Handler(); FrameLayout root; ImageView image; VideoView video; TextView help; Uri sourceUri,externalAudio; int brightness=0,orientationChoice=0,fps=24,frameIndex=0,partIndex=0,iteration=0; boolean videoMode=false,stopped=false; ArrayList<Part> parts=new ArrayList<>(); MediaPlayer sound;
 static class Part {String name;int count=1,pause=0;ArrayList<byte[]> frames=new ArrayList<>();byte[] audio;}
 Runnable tick;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);readExtras();fullImmersive();setBrightness();build();}
 void readExtras(){String u=getIntent().getStringExtra("uri");sourceUri=Uri.parse(u);brightness=getIntent().getIntExtra("brightness",0);orientationChoice=getIntent().getIntExtra("orientation",0);String a=getIntent().getStringExtra("audio");if(a!=null)externalAudio=Uri.parse(a);}
 void fullImmersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
 void setBrightness(){WindowManager.LayoutParams p=getWindow().getAttributes();p.screenBrightness=brightness==0?WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE:brightness/100f;getWindow().setAttributes(p);}
 int dp(int d){return (int)(d*getResources().getDisplayMetrics().density+.5f);}
 void build(){root=new FrameLayout(this);root.setBackgroundColor(0xff000000);image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);root.addView(image,new FrameLayout.LayoutParams(-1,-1));video=new VideoView(this);root.addView(video,new FrameLayout.LayoutParams(-1,-1));video.setVisibility(View.GONE);help=new TextView(this);help.setTextColor(0xffffffff);help.setTextSize(16);help.setGravity(Gravity.CENTER);help.setPadding(dp(26),dp(18),dp(26),dp(18));help.setBackgroundColor(0xcc000000);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);root.addView(help,hp);help.setVisibility(View.GONE);setContentView(root);String path=sourceUri.getLastPathSegment();String mime=getContentResolver().getType(sourceUri);videoMode=(mime!=null&&mime.startsWith("video/"))||(path!=null&&(path.toLowerCase(Locale.ROOT).endsWith(".mp4")||path.toLowerCase(Locale.ROOT).endsWith(".webm")||path.toLowerCase(Locale.ROOT).endsWith(".mkv")));if(videoMode)playVideo();else loadZip();}
 void applyOrientation(int w,int h){if(w>0&&h>0){setRequestedOrientation(h>=w?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);return;}if(orientationChoice==1){setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);return;}if(orientationChoice==2){setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);return;}new android.app.AlertDialog.Builder(this).setTitle("Elige orientación").setMessage("No pude detectar si el archivo es vertical u horizontal.").setPositiveButton("Vertical",(d,wid)->setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)).setNegativeButton("Horizontal",(d,wid)->setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)).setOnCancelListener(d->finish()).show();}
 void playVideo(){try{videoMode=true;video.setVisibility(View.VISIBLE);image.setVisibility(View.GONE);MediaMetadataRetriever m=new MediaMetadataRetriever();m.setDataSource(this,sourceUri);String w=m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH),h=m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT),rotation=m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);int wi=Integer.parseInt(w),he=Integer.parseInt(h),r=rotation==null?0:Integer.parseInt(rotation);if(r==90||r==270){int x=wi;wi=he;he=x;}m.release();applyOrientation(wi,he);video.setVideoURI(sourceUri);video.setOnPreparedListener(mp->{mp.setLooping(true);if(externalAudio!=null){mp.setVolume(1,1);}mp.start();});video.setOnErrorListener((mp,what,extra)->{showMessage("No se pudo reproducir el video seleccionado.");return true;});}catch(Exception e){showMessage("No pude leer las dimensiones del video. Elige orientación y vuelve a intentar.");applyOrientation(0,0);video.setVideoURI(sourceUri);video.setOnPreparedListener(MediaPlayer::start);}}
 void loadZip(){try(InputStream raw=getContentResolver().openInputStream(sourceUri);ZipInputStream zin=new ZipInputStream(raw)){if(zin==null)throw new Exception("No se pudo abrir el archivo");Map<String,byte[]> entries=new HashMap<>();ZipEntry ent;while((ent=zin.getNextEntry())!=null){if(ent.isDirectory())continue;String n=ent.getName();if(n.endsWith(".png")||n.endsWith(".wav")||n.endsWith("desc.txt")){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[32768];int c;while((c=zin.read(b))>0)out.write(b,0,c);entries.put(n,out.toByteArray());}}byte[] desc=entries.get("desc.txt");if(desc==null)throw new Exception("El ZIP no contiene desc.txt de bootanimation");parseDesc(new String(desc,java.nio.charset.StandardCharsets.UTF_8),entries);if(parts.isEmpty())throw new Exception("No encontré fotogramas PNG");int[] wh=dimensions(parts.get(0).frames.get(0));applyOrientation(wh[0],wh[1]);if(externalAudio!=null)playExternalSound();beginPart(0);}catch(Exception e){showMessage("No pude abrir el archivo de animación: "+e.getMessage());}}
 void parseDesc(String desc,Map<String,byte[]> entries){String[] lines=desc.split("\\r?\\n");if(lines.length==0)return;String[] head=lines[0].trim().split("\\s+");int width=0,height=0;try{width=Integer.parseInt(head[0]);height=Integer.parseInt(head[1]);if(head.length>2)fps=Math.max(1,Math.min(60,Integer.parseInt(head[2])));}catch(Exception ignored){}for(int i=1;i<lines.length;i++){String line=lines[i].trim();if(line.isEmpty()||line.startsWith("#"))continue;String[] a=line.split("\\s+");if(a.length<4||!(a[0].equals("p")||a[0].equals("c")||a[0].equals("f")))continue;Part p=new Part();try{p.count=Integer.parseInt(a[1]);p.pause=Integer.parseInt(a[2]);}catch(Exception e){continue;}p.name=a[3];String prefix=p.name.endsWith("/")?p.name:p.name+"/";for(String name:entries.keySet()){if(name.startsWith(prefix)&&name.toLowerCase(Locale.ROOT).endsWith(".png"))p.frames.add(entries.get(name));else if(name.equals(prefix+"audio.wav"))p.audio=entries.get(name);} // sort filenames from archive
   ArrayList<String> names=new ArrayList<>();for(String n:entries.keySet())if(n.startsWith(prefix)&&n.toLowerCase(Locale.ROOT).endsWith(".png"))names.add(n);Collections.sort(names);p.frames.clear();for(String n:names)p.frames.add(entries.get(n));if(!p.frames.isEmpty())parts.add(p);
  }}
 int[] dimensions(byte[] bytes){BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);return new int[]{o.outWidth,o.outHeight};}
 void beginPart(int idx){if(stopped||parts.isEmpty())return;if(idx>=parts.size()){partIndex=0;iteration++;idx=0;}partIndex=idx;Part p=parts.get(partIndex);frameIndex=0;playPartAudio(p.audio);displayFrame(p.frames.get(0));if(tick!=null)handler.removeCallbacks(tick);tick=new Runnable(){public void run(){if(stopped)return;frameIndex++;if(frameIndex>=p.frames.size()){int loops=p.count==0?1:Math.max(1,p.count);iteration++;if(iteration<loops){frameIndex=0;playPartAudio(p.audio);}else{iteration=0;beginPart(partIndex+1);return;}}displayFrame(p.frames.get(frameIndex));handler.postDelayed(this,1000/fps);}};handler.postDelayed(tick,1000/fps);}
 void displayFrame(byte[] data){BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(data,0,data.length,o);int sw=Math.max(1,root.getWidth()),sh=Math.max(1,root.getHeight());int scale=1;while(o.outWidth/scale>sw*1.5||o.outHeight/scale>sh*1.5)scale*=2;o.inJustDecodeBounds=false;o.inSampleSize=scale;Bitmap b=BitmapFactory.decodeByteArray(data,0,data.length,o);if(b!=null)image.setImageBitmap(b);}
 void playPartAudio(byte[] bytes){if(externalAudio!=null)return;stopSound();if(bytes==null)return;try{File f=new File(getCacheDir(),"bootpart.wav");try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}sound=new MediaPlayer();sound.setDataSource(f.getAbsolutePath());sound.setOnPreparedListener(MediaPlayer::start);sound.prepareAsync();}catch(Exception ignored){}}
 void playExternalSound(){try{sound=new MediaPlayer();sound.setDataSource(this,externalAudio);sound.setLooping(true);sound.setOnPreparedListener(MediaPlayer::start);sound.prepareAsync();}catch(Exception e){Toast.makeText(this,"No pude reproducir el audio seleccionado",Toast.LENGTH_SHORT).show();}}
 void stopSound(){if(sound!=null){try{sound.stop();}catch(Exception ignored){}sound.release();sound=null;}}
 void showMessage(String s){help.setText(s+"\n\nToca la pantalla para salir.");help.setVisibility(View.VISIBLE);root.setOnClickListener(v->finish());}
 @Override public void onWindowFocusChanged(boolean has){super.onWindowFocusChanged(has);if(has)fullImmersive();}
 @Override protected void onDestroy(){stopped=true;if(tick!=null)handler.removeCallbacks(tick);stopSound();if(video!=null)video.stopPlayback();super.onDestroy();}
}
