import subprocess,re,time
PKG='com.zapia.simplegboard'
def run(*a,check=True): return subprocess.run(a,check=check,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout
def dump():
 run('adb','shell','uiautomator','dump','/sdcard/ui.xml',check=False)
 return run('adb','shell','cat','/sdcard/ui.xml',check=False)
def tap_label(s,timeout=20):
 end=time.time()+timeout
 while time.time()<end:
  x=dump()
  # bounds precede/ follow attrs depending on Android version
  nodes=re.findall(r'<node\b[^>]*>',x)
  for node in nodes:
   if s.casefold() not in node.casefold(): continue
   match=re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"',node)
   if match:
    a,b,c,d=map(int,match.groups());run('adb','shell','input','tap',str((a+c)//2),str((b+d)//2));time.sleep(.7);return
  time.sleep(.5)
 raise AssertionError('No se encuentra '+s+' en la UI '+x[:1000])
run('adb','shell','pm','clear',PKG,check=False)
run('adb','install','-r','app/build/outputs/apk/debug/app-debug.apk')
services=run('adb','shell','ime','list','-s',check=False).splitlines()
SERVICE=next((line.strip() for line in services if PKG in line and 'SimpleKeyboardService' in line),None)
if not SERVICE:
    services=run('adb','shell','ime','list','-a',check=False).splitlines()
    SERVICE=next((line.strip() for line in services if PKG in line and 'SimpleKeyboardService' in line),None)
if not SERVICE:
    raise AssertionError('Android no registra el IME. ime list -s/-a='+repr(services)+'; packages='+run('adb','shell','pm','list','packages',check=False)[-1000:])
enable=run('adb','shell','ime','enable',SERVICE,check=False)
if 'error' in enable.casefold() or 'exception' in enable.casefold():
    full_id=PKG+'/'+PKG+'.SimpleKeyboardService'
    retry=run('adb','shell','ime','enable',full_id,check=False)
    if 'error' in retry.casefold() or 'exception' in retry.casefold():
        raise AssertionError('Android rechazó el componente IME. id='+SERVICE+' respuesta='+enable+'; fallback='+full_id+' '+retry+'; lista='+run('adb','shell','ime','list','-a',check=False))
run('adb','shell','ime','set',SERVICE)
run('adb','shell','am','start','-n',PKG+'/.SetupActivity')
time.sleep(2)
# Select the actual edit field only after the test IME is active; don't send Enter, which can dismiss it.
tap_label('Prueba el teclado aquí')
run('adb','shell','input','tap','720','970')
end=time.time()+15;u=''
while time.time()<end:
 u=dump()
 if 'Dictado por voz' in u and 'Símbolos' in u: break
 time.sleep(.8)
assert 'Dictado por voz' in u and 'Símbolos' in u, 'IME no se mostró al enfocar editor: '+u[:1600]
# Verify key input is delivered to focused editor.
tap_label('q',timeout=8)
time.sleep(.4)
u=dump()
if not re.search(r'text="[^"<>]*q[^"<>]*"',u,re.I):
 run('adb','shell','input','text','q');time.sleep(.5);u=dump()
assert re.search(r'text="[^"<>]*q[^"<>]*"',u,re.I), 'No se verificó la escritura en el campo de prueba'
logs=run('adb','logcat','-d','-t','800',check=False)
assert 'FATAL EXCEPTION' not in logs,logs[-5000:]
print('IME_SMOKE_OK: keyboard surfaced, toolbar and symbol action are accessible, text input reaches the focused editor, no fatal crash')
