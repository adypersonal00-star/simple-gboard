package com.zapia.bootshow;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
 static final int PICK_ANIM=10, PICK_AUDIO=11;
 int bg=Color.rgb(8,11,17), panel=Color.rgb(20,25,34), white=Color.WHITE, muted=Color.rgb(173,184,198), orange=Color.rgb(255,153,0);
 LinearLayout root; TextView brightnessLabel, selectedLabel, orientationLabel; SeekBar brightness; Uri animationUri=null,audioUri=null; int manualOrientation=0; // 0 auto, 1 portrait, 2 landscape
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);build();}
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
 TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setAllCaps(false);b.setBackground(shape(panel,14,Color.rgb(57,67,83)));return b;}
 void build(){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(20),dp(18),dp(20),dp(18));root.setBackgroundColor(bg);TextView head=text("Boot Show",29,white,true);root.addView(head);TextView intro=text("Reproduce animaciones de inicio y apagado en pantalla completa, con su sonido cuando el archivo lo incluya.",15,muted,false);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(6);root.addView(intro,ip);
 TextView sec=text("ANIMACIÓN PREDETERMINADA REAL",12,orange,true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(24);sp.bottomMargin=dp(8);root.addView(sec,sp);
 LinearLayout card=new LinearLayout(this);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setGravity(Gravity.CENTER_VERTICAL);card.setBackground(shape(panel,16,Color.rgb(54,64,80)));TextView icon=text("◉",28,orange,true);icon.setGravity(Gravity.CENTER);card.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(50)));LinearLayout info=new LinearLayout(this);info.setOrientation(1);info.setPadding(dp(12),0,0,0);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));info.addView(text("LineageOS · inicio del sistema",16,white,true));info.addView(text("Fotogramas reales · orientación horizontal · sin audio incorporado",12,muted,false));Button preview=btn("Ver");preview.setOnClickListener(v->playPreset());card.addView(preview);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);root.addView(card,cp);
 TextView attrib=text("Fuente: LineageOS android_vendor_cm, rama cm-14.1. Licencia Apache 2.0. La atribución y la licencia están incluidas con el archivo.",12,muted,false);LinearLayout.LayoutParams at=new LinearLayout.LayoutParams(-1,-2);at.topMargin=dp(7);root.addView(attrib,at);
 TextView custom=text("TUS ARCHIVOS",12,orange,true);LinearLayout.LayoutParams cs=new LinearLayout.LayoutParams(-1,-2);cs.topMargin=dp(24);root.addView(custom,cs);
 Button choose=btn("Elegir animación ZIP o video…");choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_ANIM);});LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(54));bp.topMargin=dp(7);root.addView(choose,bp);
 Button sound=btn("Elegir sonido opcional…");sound.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_AUDIO);});LinearLayout.LayoutParams sbp=new LinearLayout.LayoutParams(-1,dp(52));sbp.topMargin=dp(7);root.addView(sound,sbp);
 selectedLabel=text("No elegiste un archivo propio.",13,muted,false);LinearLayout.LayoutParams sl=new LinearLayout.LayoutParams(-1,-2);sl.topMargin=dp(4);root.addView(selectedLabel,sl);
 TextView bright=text("BRILLO DE LA PANTALLA",12,orange,true);LinearLayout.LayoutParams bl=new LinearLayout.LayoutParams(-1,-2);bl.topMargin=dp(21);root.addView(bright,bl);brightnessLabel=text("0% · Automático",14,white,true);root.addView(brightnessLabel);brightness=new SeekBar(this);brightness.setMax(100);brightness.setProgress(0);brightness.setProgressTintList(android.content.res.ColorStateList.valueOf(orange));brightness.setThumbTintList(android.content.res.ColorStateList.valueOf(white));root.addView(brightness,new LinearLayout.LayoutParams(-1,dp(42)));brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){brightnessLabel.setText(p==0?"0% · Automático":p+"% ");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
 orientationLabel=text("Si no se detecta la orientación, elige una:",14,white,true);LinearLayout.LayoutParams ol=new LinearLayout.LayoutParams(-1,-2);ol.topMargin=dp(8);root.addView(orientationLabel);LinearLayout dirs=new LinearLayout(this);Button vert=btn("Vertical");Button horiz=btn("Horizontal");vert.setOnClickListener(v->{manualOrientation=1;markOrientation(vert,horiz);});horiz.setOnClickListener(v->{manualOrientation=2;markOrientation(horiz,vert);});dirs.addView(vert,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(dp(8),1);dirs.addView(new View(this),gap);dirs.addView(horiz,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2);dp.topMargin=dp(6);root.addView(dirs,dp);
 Button go=btn("▶   COMENZAR A PANTALLA COMPLETA");go.setTextColor(Color.BLACK);go.setBackground(shape(orange,16,orange));go.setOnClickListener(v->{if(animationUri==null){Toast.makeText(this,"Elige un archivo ZIP o video primero.",Toast.LENGTH_SHORT).show();return;}launch(animationUri.toString(),false);});LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(58));gp.topMargin=dp(18);root.addView(go,gp);
 android.widget.ScrollView scroll=new android.widget.ScrollView(this);scroll.setFillViewport(true);scroll.addView(root);setContentView(scroll); }
 void markOrientation(Button selected,Button other){selected.setTextColor(Color.BLACK);selected.setBackground(shape(orange,14,orange));other.setTextColor(white);other.setBackground(shape(panel,14,Color.rgb(57,67,83)));}
 void playPreset(){try{File f=new File(getCacheDir(),"LineageOS.bootanimation.zip");try(InputStream in=getAssets().open("presets/LineageOS.bootanimation.zip");FileOutputStream out=new FileOutputStream(f)){byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}launch(Uri.fromFile(f).toString(),true);}catch(Exception e){Toast.makeText(this,"No pude cargar la animación real.",Toast.LENGTH_LONG).show();}}
 void launch(String uri,boolean preset){Intent p=new Intent(this,PlayerActivity.class);p.putExtra("uri",uri);p.putExtra("preset",preset);p.putExtra("brightness",brightness.getProgress());p.putExtra("orientation",manualOrientation);if(audioUri!=null)p.putExtra("audio",audioUri.toString());startActivity(p);}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null||d.getData()==null)return;if(r==PICK_ANIM){animationUri=d.getData();try{getContentResolver().takePersistableUriPermission(animationUri,d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}selectedLabel.setText("Animación: "+animationUri.getLastPathSegment());}else if(r==PICK_AUDIO){audioUri=d.getData();try{getContentResolver().takePersistableUriPermission(audioUri,d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}Toast.makeText(this,"Sonido seleccionado.",Toast.LENGTH_SHORT).show();}}
}
