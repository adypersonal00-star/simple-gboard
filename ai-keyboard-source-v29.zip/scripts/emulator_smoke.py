import subprocess,re,time
PKG='com.zapia.simplegboard'; SERVICE=PKG+'/'+PKG+'.SimpleKeyboardService'
def run(*a,check=True): return subprocess.run(a,check=check,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout
def dump():
 run('adb','shell','uiautomator','dump','/sdcard/ui.xml',check=False)
 return run('adb','shell','cat','/sdcard/ui.xml',check=False)
def tap_label(s,timeout=20):
 end=time.time()+timeout
 while time.time()<end:
  x=dump()
  for node in re.findall(r'<node\b[^>]*>',x):
   if s.casefold() not in node.casefold(): continue
   m=re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"',node)
   if m:
    a,b,c,d=map(int,m.groups());run('adb','shell','input','tap',str((a+c)//2),str((b+d)//2));time.sleep(.8);return
  time.sleep(.5)
 raise AssertionError('No se encuentra '+s+' en la UI '+x[:1000])
run('adb','shell','pm','clear',PKG,check=False)
run('adb','install','-r','app/build/outputs/apk/debug/app-debug.apk')
enable=run('adb','shell','ime','enable',SERVICE,check=False)
if 'error' in enable.casefold() or 'exception' in enable.casefold() or 'unknown' in enable.casefold():
    details='enable='+enable+'; ime='+run('adb','shell','ime','list','-a',check=False)+'; query='+run('adb','shell','cmd','package','query-services','-a','android.view.InputMethod','-p',PKG,check=False)+'; package='+run('adb','shell','dumpsys','package',PKG,check=False)[-6000:]
    raise AssertionError('Android IME registration details: '+details)
set_out=run('adb','shell','ime','set',SERVICE,check=False)
if 'error' in set_out.casefold() or 'exception' in set_out.casefold():
    raise AssertionError('Android IME selection failed: '+set_out+'; ime list='+run('adb','shell','ime','list','-a',check=False))
run('adb','shell','am','start','-n',PKG+'/.SetupActivity')
time.sleep(2)
tap_label('Prueba el teclado aquí')
# Tap the editor's text region; the IME itself may render in a separate window not returned by uiautomator dump.
run('adb','shell','input','tap','720','980');time.sleep(2)
state=run('adb','shell','dumpsys','input_method',check=False)
assert SERVICE in state, 'Android no tiene seleccionado AI Keyboard en InputMethodManager: '+state[-2500:]
# Send a printable character through the selected input method and verify it reached the setup editor.
run('adb','shell','input','text','q');time.sleep(1)
u=dump()
assert re.search(r'<node[^>]*class="android.widget.EditText"[^>]*text="[^"]*q[^"]*"',u,re.I) or re.search(r'<node[^>]*text="[^"]*q[^"]*"[^>]*class="android.widget.EditText"',u,re.I), 'El texto de prueba no llegó al editor: '+u[-1600:]
logs=run('adb','logcat','-d','-t','1000',check=False)
assert 'FATAL EXCEPTION' not in logs,logs[-5000:]
print('IME_SMOKE_OK: app launched, AI Keyboard selected, text input delivered to editor, no fatal crash')
